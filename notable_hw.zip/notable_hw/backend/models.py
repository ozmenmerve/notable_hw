from django.db import models

class Doctors(models.Model):
    last_name = models.CharField(max_length=50)
    first_name = models.CharField(max_length=50)

class Patients(models.Model):
    doctor = models.ForeignKey(Doctors, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    time = models.CharField(max_length=50)
    kind = models.CharField(max_length=50)
