from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from backend.api.serializers import DoctorsSerializer, PatientsSerializer
from backend.models import Doctors, Patients

context = dict()

class DoctorsView(APIView):
    def get_object(self):
        try:
            
            return Doctors.objects.all()
        except Doctors.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
   
    def get(self, request):
        all = [] 
        ret = self.get_object()
        for obj in ret:
            all.append("{}, {}".format(obj.last_name, obj.first_name))
      
        print(all)
        context['doctors'] = all
        return Response(context, status=status.HTTP_200_OK)

class PatientsView(APIView):
    def get_object(self, doctor):
        try:
            return Patients.objects.filter(doctor=doctor)
        except Patients.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

    def get(self, request, pk):
        all = []
        ret = self.get_object(pk)
        for obj in ret:
            all.append("{} {} {} {}".format(obj.name, obj.date, obj.time, obj.kind))
        
        context['patients'] = all
        return Response(context, status=status.HTTP_200_OK) 
