from django.urls import path, re_path
from rest_framework.urlpatterns import format_suffix_patterns
from backend.api.views import DoctorsView, PatientsView

urlpatterns = [
    path('doctors', DoctorsView.as_view(), name="doctors"),
    path('patients', PatientsView.as_view(), name="patients"),
    re_path(r'^patients/(?P<pk>[0-9]+)$', PatientsView.as_view(), name="patients")
]
