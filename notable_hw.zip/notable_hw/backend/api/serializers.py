from rest_framework import serializers
from backend.models import Doctors, Patients
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
class DoctorsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Doctors
        fields = '__all__'

@csrf_exempt
class PatientsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Patients
        fields = '__all__'
