from django.contrib import admin
from backend.models import Doctors, Patients

admin.site.register(Doctors)
admin.site.register(Patients)
