- First create a virtual environment
$python -m venv <environment name>

- Activate Virtual Enviorment
source <environment name>/bin/activate

- Install Dependecies using following command
pip install -r notable_hw/requirements.txt

To run application run below command
python notable_hw/manage.py runserver

For rest enpoints 
http://127.0.0.1:8000/api/doctors : Return Doctors List
http://127.0.0.1:8000/api/patients/<patient-id> Return specific Patient ID information 

